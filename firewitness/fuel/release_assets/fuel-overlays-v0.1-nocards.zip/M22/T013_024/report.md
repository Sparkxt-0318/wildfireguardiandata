# Fuel-map check: T013_024 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3554562 | 88.9 % |
| contradicted | 120853 | 3.0 % |
| stale | 14638 | 0.4 % |
| unknown | 309947 | 7.7 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 5362 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 12 |
| R1.3 burnable class on open water | 13 |
| R1.5 burnable class on pavement/built | 40 |
| R1.6 burnable class on bare ground | 1375 |
| R1.7 unburnable class on natural vegetation | 100967 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 9094 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 21220 |
| S1 wildfire perimeter after the map year | 14631 |
| S2 tree-cover loss after the map year (Hansen) | 7 |

Cells with a suggested class: 26196.

## Evidence cards (examples)

```
Cell (0,590)  verdict: CONTRADICTED  map class 185 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 18
  canopy_max_m: 5
  canopy_share_ge3m_percent: 11
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 8
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 142 group SH
```

```
Cell (1245,633)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 147 group SH
```

```
Cell (1545,331)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 1 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 16
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 33, 20: 66}
  hansen_tree_cover_2000: 16
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1820,149)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group SH
```

```
Cell (1999,1910)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
