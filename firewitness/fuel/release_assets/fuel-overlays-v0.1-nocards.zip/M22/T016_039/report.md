# Fuel-map check: T016_039 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3553832 | 88.8 % |
| contradicted | 144439 | 3.6 % |
| stale | 37703 | 0.9 % |
| unknown | 264026 | 6.6 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 48275 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 2027 |
| R1.3 burnable class on open water | 343 |
| R1.6 burnable class on bare ground | 228 |
| R1.7 unburnable class on natural vegetation | 51709 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 41035 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 3141 |
| S1 wildfire perimeter after the map year | 28987 |
| S2 tree-cover loss after the map year (Hansen) | 8716 |

Cells with a suggested class: 33340.

## Evidence cards (examples)

```
Cell (0,141)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.3: burnable class on open water
  tree evidence score 0 from 4 independent layers
  nlcd2021: 11 (open water)
  tcc2021_percent: 0
  canopy_max_m: 12
  canopy_share_ge3m_percent: 22
  worldcover_percent: {10: 44, 80: 55}
  hansen_tree_cover_2000: 32
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 98 group None
```

```
Cell (451,319)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 101 group GR
```

```
Cell (956,53)  verdict: CONTRADICTED  map class 93 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1508,740)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

```
Cell (1999,1968)  verdict: CONTRADICTED  map class 141 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
