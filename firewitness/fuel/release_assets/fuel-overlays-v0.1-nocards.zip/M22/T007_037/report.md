# Fuel-map check: T007_037 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3917908 | 97.9 % |
| contradicted | 76843 | 1.9 % |
| stale | 521 | 0.0 % |
| unknown | 4728 | 0.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 642 |
| R1.6 burnable class on bare ground | 160 |
| R1.7 unburnable class on natural vegetation | 9993 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 65607 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1939 |
| S1 wildfire perimeter after the map year | 521 |

Cells with a suggested class: 21653.

## Evidence cards (examples)

```
Cell (0,883)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 4
  canopy_share_ge3m_percent: 22
  worldcover_percent: {20: 11, 30: 88}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (955,47)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 55, 60: 44}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

```
Cell (1392,1159)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

```
Cell (1579,413)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 102 group GR
```

```
Cell (1999,1711)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
