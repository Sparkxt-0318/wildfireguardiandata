# Fuel-map check: T019_033 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3625135 | 90.6 % |
| contradicted | 161968 | 4.0 % |
| stale | 723 | 0.0 % |
| unknown | 212174 | 5.3 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 131446 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 479 |
| R1.3 burnable class on open water | 27 |
| R1.6 burnable class on bare ground | 190 |
| R1.7 unburnable class on natural vegetation | 26450 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 1837 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 4683 |
| S1 wildfire perimeter after the map year | 45 |
| S2 tree-cover loss after the map year (Hansen) | 678 |

Cells with a suggested class: 6514.

## Evidence cards (examples)

```
Cell (0,5)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 11
  worldcover_percent: {10: 44, 30: 55}
  hansen_tree_cover_2000: 47
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (490,1493)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1246,851)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 16
  canopy_max_m: 15
  canopy_share_ge3m_percent: 77
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 87
  hansen_loss_year: 2017
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

```
Cell (1649,1265)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 66, 60: 33}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1999,1973)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
