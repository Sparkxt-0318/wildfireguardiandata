# Fuel-map check: T012_027 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3081842 | 77.0 % |
| contradicted | 70912 | 1.8 % |
| stale | 1621 | 0.0 % |
| unknown | 845625 | 21.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 22472 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 10 |
| R1.3 burnable class on open water | 20 |
| R1.6 burnable class on bare ground | 1518 |
| R1.7 unburnable class on natural vegetation | 32923 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 13973 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 124 |
| S1 wildfire perimeter after the map year | 1375 |
| S2 tree-cover loss after the map year (Hansen) | 246 |

Cells with a suggested class: 39742.

## Evidence cards (examples)

```
Cell (0,284)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 102 group GR
```

```
Cell (533,411)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 66, 60: 33}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 141 group SH
```

```
Cell (795,221)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 88, 60: 11}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 145 group SH
```

```
Cell (1312,956)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 102 group GR
```

```
Cell (1999,1426)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class None group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
