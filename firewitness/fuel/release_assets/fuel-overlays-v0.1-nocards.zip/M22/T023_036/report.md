# Fuel-map check: T023_036 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 2679305 | 67.0 % |
| contradicted | 1293716 | 32.3 % |
| stale | 4495 | 0.1 % |
| unknown | 22484 | 0.6 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 1157688 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 24 |
| R1.3 burnable class on open water | 386 |
| R1.6 burnable class on bare ground | 45242 |
| R1.7 unburnable class on natural vegetation | 93214 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 30662 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 7754 |
| S1 wildfire perimeter after the map year | 4495 |

Cells with a suggested class: 206631.

## Evidence cards (examples)

```
Cell (0,133)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 142 group SH
```

```
Cell (364,644)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 88, 60: 11}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (733,851)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1182,559)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1999,1997)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
