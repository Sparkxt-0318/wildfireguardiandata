# Fuel-map check: T023_042 (M22)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3633834 | 90.8 % |
| contradicted | 154688 | 3.9 % |
| stale | 18104 | 0.5 % |
| unknown | 193374 | 4.8 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 24360 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 313 |
| R1.3 burnable class on open water | 299 |
| R1.6 burnable class on bare ground | 53 |
| R1.7 unburnable class on natural vegetation | 123154 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 6291 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 292 |
| S1 wildfire perimeter after the map year | 17749 |
| S2 tree-cover loss after the map year (Hansen) | 355 |

Cells with a suggested class: 108433.

## Evidence cards (examples)

```
Cell (0,833)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 9
  canopy_max_m: 6
  canopy_share_ge3m_percent: 22
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 5
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (930,560)  verdict: CONTRADICTED  map class 93 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

```
Cell (1253,40)  verdict: CONTRADICTED  map class 93 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 102 group GR
```

```
Cell (1567,244)  verdict: CONTRADICTED  map class 93 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
  suggestion: class 102 group GR
```

```
Cell (1999,1977)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2022
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
