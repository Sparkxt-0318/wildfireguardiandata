# Fuel-map check: F_2018_WA_boyds (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 82252 | 69.8 % |
| contradicted | 10466 | 8.9 % |
| stale | 130 | 0.1 % |
| unknown | 24962 | 21.2 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 2005 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 7430 |
| R1.3 burnable class on open water | 115 |
| R1.5 burnable class on pavement/built | 21 |
| R1.7 unburnable class on natural vegetation | 774 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 9 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 143 |
| R3b observed spread faster than the class can produce | 139 |
| S2 tree-cover loss after the map year (Hansen) | 130 |

Cells with a suggested class: 868.

## Evidence cards (examples)

```
Cell (0,36)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 75
  canopy_max_m: 30
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 98
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (70,140)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 51
  canopy_max_m: 21
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 35
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (153,171)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 9
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (245,97)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 58
  canopy_max_m: 26
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 73
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (373,297)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 11
  canopy_max_m: 19
  canopy_share_ge3m_percent: 88
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 2
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
