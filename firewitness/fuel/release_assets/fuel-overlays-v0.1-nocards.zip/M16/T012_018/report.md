# Fuel-map check: T012_018 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3614760 | 90.4 % |
| contradicted | 312904 | 7.8 % |
| stale | 15 | 0.0 % |
| unknown | 72321 | 1.8 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 2631 |
| R1.3 burnable class on open water | 8 |
| R1.5 burnable class on pavement/built | 253 |
| R1.6 burnable class on bare ground | 33733 |
| R1.7 unburnable class on natural vegetation | 275599 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 692 |
| S1 wildfire perimeter after the map year | 15 |

Cells with a suggested class: 137546.

## Evidence cards (examples)

```
Cell (0,198)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 66, 60: 33}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 141 group SH
```

```
Cell (705,867)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group SH
```

```
Cell (1104,1588)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 66, 60: 33}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 141 group SH
```

```
Cell (1642,100)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group SH
```

```
Cell (1999,1997)  verdict: CONTRADICTED  map class 121 (GS)
  rule R1.6: burnable class on bare ground
  tree evidence score -4 from 4 independent layers
  nlcd2021: 31 (barren)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 99 group None
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
