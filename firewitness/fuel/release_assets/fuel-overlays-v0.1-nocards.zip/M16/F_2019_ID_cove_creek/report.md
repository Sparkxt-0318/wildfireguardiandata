# Fuel-map check: F_2019_ID_cove_creek (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 84227 | 71.6 % |
| contradicted | 17074 | 14.5 % |
| stale | 4 | 0.0 % |
| unknown | 16335 | 13.9 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 12392 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 216 |
| R1.3 burnable class on open water | 116 |
| R1.7 unburnable class on natural vegetation | 3604 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 112 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 4109 |
| R3b observed spread faster than the class can produce | 124 |
| S2 tree-cover loss after the map year (Hansen) | 4 |

Cells with a suggested class: 2599.

## Evidence cards (examples)

```
Cell (0,2)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 11
  canopy_max_m: 11
  canopy_share_ge3m_percent: 33
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 69
  hansen_loss_year: 2012
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (48,211)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 11
  worldcover_percent: {30: 33, 60: 66}
  hansen_tree_cover_2000: 12
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (95,149)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 5
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (185,311)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 10
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 55, 30: 44}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (339,341)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 7
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
