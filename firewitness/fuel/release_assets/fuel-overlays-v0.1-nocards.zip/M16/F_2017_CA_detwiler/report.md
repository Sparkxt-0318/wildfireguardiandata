# Fuel-map check: F_2017_CA_detwiler (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 735834 | 69.8 % |
| contradicted | 163718 | 15.5 % |
| stale | 0 | 0.0 % |
| unknown | 154276 | 14.6 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 42186 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 264 |
| R1.3 burnable class on open water | 58 |
| R1.5 burnable class on pavement/built | 17 |
| R1.7 unburnable class on natural vegetation | 12669 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 53669 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 12188 |
| R3b observed spread faster than the class can produce | 60122 |

Cells with a suggested class: 42238.

## Evidence cards (examples)

```
Cell (0,76)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 5
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (360,484)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 6
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (546,300)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 11
  canopy_max_m: 8
  canopy_share_ge3m_percent: 88
  worldcover_percent: {10: 55, 30: 44}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (843,181)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 12
  canopy_share_ge3m_percent: 77
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 7
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (1313,649)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 9
  canopy_max_m: 5
  canopy_share_ge3m_percent: 11
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
