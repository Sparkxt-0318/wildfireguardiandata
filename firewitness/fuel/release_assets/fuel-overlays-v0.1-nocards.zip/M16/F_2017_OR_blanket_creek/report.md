# Fuel-map check: F_2017_OR_blanket_creek (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 465596 | 83.1 % |
| contradicted | 38720 | 6.9 % |
| stale | 0 | 0.0 % |
| unknown | 56147 | 10.0 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 21474 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 4103 |
| R1.7 unburnable class on natural vegetation | 3285 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 17 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1048 |
| R3b observed spread faster than the class can produce | 13444 |

Cells with a suggested class: 124.

## Evidence cards (examples)

```
Cell (0,325)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 90
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (273,644)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 61
  canopy_max_m: 20
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 51
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (358,524)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 95
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (464,453)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 70
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (680,733)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 65
  canopy_max_m: 16
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 45
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
