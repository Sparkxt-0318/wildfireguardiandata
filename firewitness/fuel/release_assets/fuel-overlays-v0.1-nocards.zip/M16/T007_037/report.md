# Fuel-map check: T007_037 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3922951 | 98.1 % |
| contradicted | 22658 | 0.6 % |
| stale | 49399 | 1.2 % |
| unknown | 4992 | 0.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 851 |
| R1.6 burnable class on bare ground | 64 |
| R1.7 unburnable class on natural vegetation | 13058 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 13427 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1478 |
| S1 wildfire perimeter after the map year | 49399 |

Cells with a suggested class: 3436.

## Evidence cards (examples)

```
Cell (0,883)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 4
  canopy_share_ge3m_percent: 22
  worldcover_percent: {20: 11, 30: 88}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (721,195)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1387,488)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 33, 30: 66}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1599,471)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1999,1436)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
