# Fuel-map check: T012_027 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3113427 | 77.8 % |
| contradicted | 36186 | 0.9 % |
| stale | 7600 | 0.2 % |
| unknown | 842787 | 21.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 15190 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 7 |
| R1.3 burnable class on open water | 20 |
| R1.5 burnable class on pavement/built | 18 |
| R1.6 burnable class on bare ground | 1518 |
| R1.7 unburnable class on natural vegetation | 4858 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 15045 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 6 |
| S1 wildfire perimeter after the map year | 7124 |
| S2 tree-cover loss after the map year (Hansen) | 476 |

Cells with a suggested class: 17643.

## Evidence cards (examples)

```
Cell (0,284)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (229,1218)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 22, 30: 77}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (702,1039)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1269,1055)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 11, 30: 88}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (1999,1426)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
