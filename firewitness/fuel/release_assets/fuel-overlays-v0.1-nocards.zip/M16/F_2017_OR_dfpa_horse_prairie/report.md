# Fuel-map check: F_2017_OR_dfpa_horse_prairie (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 187722 | 78.4 % |
| contradicted | 29472 | 12.3 % |
| stale | 0 | 0.0 % |
| unknown | 22344 | 9.3 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 26502 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 466 |
| R1.7 unburnable class on natural vegetation | 1434 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 6 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 518 |
| R3b observed spread faster than the class can produce | 1122 |

Cells with a suggested class: 2332.

## Evidence cards (examples)

```
Cell (0,101)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 84
  canopy_max_m: 29
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 96
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (151,251)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 10
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 64
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (247,129)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 12
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 100
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (353,393)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 29
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 22, 30: 77}
  hansen_tree_cover_2000: 100
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (497,471)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 72
  canopy_max_m: 24
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
