# Fuel-map check: F_2017_CO_peekaboo (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 221788 | 78.4 % |
| contradicted | 41586 | 14.7 % |
| stale | 0 | 0.0 % |
| unknown | 19646 | 6.9 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 17446 |
| R1.3 burnable class on open water | 25 |
| R1.6 burnable class on bare ground | 59 |
| R1.7 unburnable class on natural vegetation | 9610 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 11711 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 142 |
| R3b observed spread faster than the class can produce | 8449 |

Cells with a suggested class: 9816.

## Evidence cards (examples)

```
Cell (0,57)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 5
  canopy_max_m: 3
  canopy_share_ge3m_percent: 11
  worldcover_percent: {20: 22, 30: 77}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (168,107)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 0
  canopy_max_m: 4
  canopy_share_ge3m_percent: 11
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (247,273)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 4
  canopy_share_ge3m_percent: 77
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 16
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (337,14)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 13
  canopy_share_ge3m_percent: 11
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 142 group SH
```

```
Cell (529,474)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 11
  worldcover_percent: {10: 11, 20: 88}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 142 group SH
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
