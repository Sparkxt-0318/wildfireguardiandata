# Fuel-map check: F_2019_WY_pedro_mountain (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 298975 | 86.9 % |
| contradicted | 38283 | 11.1 % |
| stale | 0 | 0.0 % |
| unknown | 6635 | 1.9 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 6763 |
| R1.3 burnable class on open water | 11 |
| R1.6 burnable class on bare ground | 3 |
| R1.7 unburnable class on natural vegetation | 817 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 29558 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 120 |
| R3b observed spread faster than the class can produce | 3745 |

Cells with a suggested class: 6849.

## Evidence cards (examples)

```
Cell (0,281)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (187,371)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 10
  canopy_share_ge3m_percent: 11
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (259,280)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 6
  canopy_max_m: 14
  canopy_share_ge3m_percent: 33
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (372,299)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 7
  canopy_max_m: 8
  canopy_share_ge3m_percent: 55
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 30
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (560,416)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 10
  canopy_share_ge3m_percent: 88
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 3
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 142 group SH
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
