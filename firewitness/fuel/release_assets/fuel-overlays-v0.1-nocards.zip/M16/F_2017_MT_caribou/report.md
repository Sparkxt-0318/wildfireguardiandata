# Fuel-map check: F_2017_MT_caribou (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 153925 | 43.4 % |
| contradicted | 37642 | 10.6 % |
| stale | 0 | 0.0 % |
| unknown | 162917 | 46.0 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 11847 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 23344 |
| R1.3 burnable class on open water | 11 |
| R1.7 unburnable class on natural vegetation | 570 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 800 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 405 |
| R3b observed spread faster than the class can produce | 1703 |
| U0 no or unmapped fuel class | 120025 |

Cells with a suggested class: 645.

## Evidence cards (examples)

```
Cell (66,1)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 0 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 6
  canopy_share_ge3m_percent: 33
  worldcover_percent: {10: 44, 30: 44, 100: 11}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (235,677)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 23
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 11, 30: 88}
  hansen_tree_cover_2000: 83
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (308,515)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 20
  canopy_share_ge3m_percent: 100
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 82
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (379,227)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 71
  canopy_max_m: 17
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 63
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (441,700)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 63
  canopy_max_m: 24
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 78
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
