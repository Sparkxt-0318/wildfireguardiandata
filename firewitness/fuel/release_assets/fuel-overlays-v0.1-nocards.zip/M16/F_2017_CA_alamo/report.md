# Fuel-map check: F_2017_CA_alamo (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 304125 | 77.5 % |
| contradicted | 37238 | 9.5 % |
| stale | 0 | 0.0 % |
| unknown | 51097 | 13.0 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 4595 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 118 |
| R1.3 burnable class on open water | 97 |
| R1.5 burnable class on pavement/built | 3 |
| R1.7 unburnable class on natural vegetation | 10252 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 16275 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1995 |
| R3b observed spread faster than the class can produce | 7160 |

Cells with a suggested class: 18995.

## Evidence cards (examples)

```
Cell (0,106)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 13
  canopy_max_m: 13
  canopy_share_ge3m_percent: 66
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (170,517)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 11
  canopy_max_m: 9
  canopy_share_ge3m_percent: 55
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 15
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (305,376)  verdict: CONTRADICTED  map class 162 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 14
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 11, 30: 88}
  hansen_tree_cover_2000: 77
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (429,378)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 8
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (632,575)  verdict: CONTRADICTED  map class 184 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 11
  canopy_max_m: 6
  canopy_share_ge3m_percent: 33
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 45
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 142 group SH
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
