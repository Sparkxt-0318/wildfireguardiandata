# Fuel-map check: F_2018_CO_416 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 511588 | 80.8 % |
| contradicted | 31790 | 5.0 % |
| stale | 480 | 0.1 % |
| unknown | 89406 | 14.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 19706 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 1225 |
| R1.3 burnable class on open water | 151 |
| R1.5 burnable class on pavement/built | 14 |
| R1.6 burnable class on bare ground | 1 |
| R1.7 unburnable class on natural vegetation | 2064 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 3429 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 123 |
| R3b observed spread faster than the class can produce | 6203 |
| S1 wildfire perimeter after the map year | 456 |
| S2 tree-cover loss after the map year (Hansen) | 24 |

Cells with a suggested class: 4372.

## Evidence cards (examples)

```
Cell (0,186)  verdict: CONTRADICTED  map class 142 (SH)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 51
  canopy_max_m: 21
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 86
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (393,474)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 7
  canopy_share_ge3m_percent: 77
  worldcover_percent: {10: 11, 30: 88}
  hansen_tree_cover_2000: 12
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (533,343)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score 0 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 16
  canopy_share_ge3m_percent: 33
  worldcover_percent: {10: 33, 30: 66}
  hansen_tree_cover_2000: 77
  hansen_loss_year: 2008
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (712,292)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 20
  canopy_share_ge3m_percent: 100
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 75
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (947,658)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 72
  hansen_loss_year: 2002
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
