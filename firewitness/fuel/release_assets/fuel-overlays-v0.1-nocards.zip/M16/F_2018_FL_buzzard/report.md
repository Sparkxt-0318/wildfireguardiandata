# Fuel-map check: F_2018_FL_buzzard (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 454834 | 53.1 % |
| contradicted | 140385 | 16.4 % |
| stale | 97630 | 11.4 % |
| unknown | 164062 | 19.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 137808 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 7787 |
| R1.3 burnable class on open water | 28 |
| R1.5 burnable class on pavement/built | 2 |
| R1.7 unburnable class on natural vegetation | 1 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 5 |
| R3b observed spread faster than the class can produce | 15180 |
| S1 wildfire perimeter after the map year | 97333 |
| S2 tree-cover loss after the map year (Hansen) | 297 |

Cells with a suggested class: 32.

## Evidence cards (examples)

```
Cell (0,49)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 90 (woody wetlands)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 22
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 6
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (172,262)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 6
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (361,799)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 12
  canopy_share_ge3m_percent: 55
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 33
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (493,83)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (758,1108)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 7
  canopy_share_ge3m_percent: 66
  worldcover_percent: {20: 11, 90: 88}
  hansen_tree_cover_2000: 3
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
