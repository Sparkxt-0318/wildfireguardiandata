# Fuel-map check: T019_033 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3568610 | 89.2 % |
| contradicted | 194997 | 4.9 % |
| stale | 23781 | 0.6 % |
| unknown | 212612 | 5.3 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 159034 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 660 |
| R1.3 burnable class on open water | 27 |
| R1.5 burnable class on pavement/built | 5 |
| R1.6 burnable class on bare ground | 191 |
| R1.7 unburnable class on natural vegetation | 25460 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 11378 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 2312 |
| S1 wildfire perimeter after the map year | 16775 |
| S2 tree-cover loss after the map year (Hansen) | 7006 |

Cells with a suggested class: 13774.

## Evidence cards (examples)

```
Cell (0,5)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 11
  worldcover_percent: {10: 44, 30: 55}
  hansen_tree_cover_2000: 47
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (285,833)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (988,313)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1602,1269)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1999,1973)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
