# Fuel-map check: F_2018_WA_cougar_creek (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 492757 | 75.5 % |
| contradicted | 90242 | 13.8 % |
| stale | 1470 | 0.2 % |
| unknown | 68147 | 10.4 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 53660 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 836 |
| R1.3 burnable class on open water | 3 |
| R1.6 burnable class on bare ground | 7 |
| R1.7 unburnable class on natural vegetation | 28646 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 69 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 7869 |
| R3b observed spread faster than the class can produce | 12108 |
| S2 tree-cover loss after the map year (Hansen) | 1470 |

Cells with a suggested class: 13464.

## Evidence cards (examples)

```
Cell (0,45)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 0 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 12
  canopy_share_ge3m_percent: 66
  worldcover_percent: {10: 88, 100: 11}
  hansen_tree_cover_2000: 18
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (334,64)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 81
  canopy_max_m: 29
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 100
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (509,416)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (622,534)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 11
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (840,746)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
