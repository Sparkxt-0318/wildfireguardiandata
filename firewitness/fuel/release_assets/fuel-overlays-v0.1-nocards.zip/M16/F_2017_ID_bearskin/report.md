# Fuel-map check: F_2017_ID_bearskin (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 317508 | 62.9 % |
| contradicted | 88607 | 17.5 % |
| stale | 0 | 0.0 % |
| unknown | 98853 | 19.6 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 36843 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 5387 |
| R1.3 burnable class on open water | 34 |
| R1.6 burnable class on bare ground | 1 |
| R1.7 unburnable class on natural vegetation | 28985 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 2002 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 18385 |
| R3b observed spread faster than the class can produce | 18658 |

Cells with a suggested class: 5861.

## Evidence cards (examples)

```
Cell (0,2)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score 0 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 0
  canopy_max_m: 11
  canopy_share_ge3m_percent: 22
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 59
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (181,120)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 25
  canopy_max_m: 13
  canopy_share_ge3m_percent: 88
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 76
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (338,354)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 11
  canopy_max_m: 6
  canopy_share_ge3m_percent: 100
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 55
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (593,468)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 7
  canopy_share_ge3m_percent: 33
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 60
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (798,615)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 11
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 79
  hansen_loss_year: 2007
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
