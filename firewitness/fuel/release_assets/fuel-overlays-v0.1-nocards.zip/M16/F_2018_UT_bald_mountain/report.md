# Fuel-map check: F_2018_UT_bald_mountain (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 397713 | 69.3 % |
| contradicted | 46386 | 8.1 % |
| stale | 61 | 0.0 % |
| unknown | 129380 | 22.6 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 23489 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 3016 |
| R1.3 burnable class on open water | 10 |
| R1.5 burnable class on pavement/built | 187 |
| R1.6 burnable class on bare ground | 54 |
| R1.7 unburnable class on natural vegetation | 10770 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 6491 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 2363 |
| R3b observed spread faster than the class can produce | 2450 |
| S2 tree-cover loss after the map year (Hansen) | 61 |

Cells with a suggested class: 7600.

## Evidence cards (examples)

```
Cell (0,2)  verdict: CONTRADICTED  map class 186 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 82 (cultivated crops)
  tcc2021_percent: 0
  canopy_max_m: 4
  canopy_share_ge3m_percent: 33
  worldcover_percent: {10: 33, 40: 66}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (224,611)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -2 from 4 independent layers
  nlcd2021: 41 (deciduous forest)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (441,177)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 11
  canopy_share_ge3m_percent: 44
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (633,166)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 11, 30: 44, 60: 44}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (868,610)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 2 from 4 independent layers
  nlcd2021: 41 (deciduous forest)
  tcc2021_percent: 0
  canopy_max_m: 9
  canopy_share_ge3m_percent: 66
  worldcover_percent: {10: 33, 30: 66}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
