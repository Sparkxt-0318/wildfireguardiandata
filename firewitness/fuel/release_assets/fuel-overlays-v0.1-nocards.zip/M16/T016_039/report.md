# Fuel-map check: T016_039 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3471900 | 86.8 % |
| contradicted | 92140 | 2.3 % |
| stale | 191612 | 4.8 % |
| unknown | 244348 | 6.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 52154 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 2294 |
| R1.3 burnable class on open water | 321 |
| R1.5 burnable class on pavement/built | 92 |
| R1.6 burnable class on bare ground | 208 |
| R1.7 unburnable class on natural vegetation | 56100 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 1697 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1663 |
| S1 wildfire perimeter after the map year | 178972 |
| S2 tree-cover loss after the map year (Hansen) | 12640 |

Cells with a suggested class: 12953.

## Evidence cards (examples)

```
Cell (0,141)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.3: burnable class on open water
  tree evidence score 0 from 4 independent layers
  nlcd2021: 11 (open water)
  tcc2021_percent: 0
  canopy_max_m: 12
  canopy_share_ge3m_percent: 22
  worldcover_percent: {10: 44, 80: 55}
  hansen_tree_cover_2000: 32
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 98 group None
```

```
Cell (422,723)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 0 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 34
  canopy_max_m: 5
  canopy_share_ge3m_percent: 33
  worldcover_percent: {100: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (759,870)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 33, 100: 66}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1175,961)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 44
  worldcover_percent: {100: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1999,1945)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 4
  canopy_share_ge3m_percent: 11
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
