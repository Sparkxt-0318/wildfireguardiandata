# Fuel-map check: F_2017_AZ_pinal (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 100268 | 66.1 % |
| contradicted | 17430 | 11.5 % |
| stale | 0 | 0.0 % |
| unknown | 34078 | 22.5 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 12709 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 708 |
| R1.7 unburnable class on natural vegetation | 1847 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 413 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1695 |
| R3b observed spread faster than the class can produce | 1769 |

Cells with a suggested class: 1828.

## Evidence cards (examples)

```
Cell (0,8)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 11
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group SH
```

```
Cell (60,119)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 11
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 4
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 147 group SH
```

```
Cell (151,344)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 22
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (303,3)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 18
  canopy_max_m: 4
  canopy_share_ge3m_percent: 100
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 33
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 147 group SH
```

```
Cell (407,370)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 3
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group SH
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
