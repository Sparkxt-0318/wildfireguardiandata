# Fuel-map check: F_2018_NM_emily (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 89587 | 60.1 % |
| contradicted | 1346 | 0.9 % |
| stale | 0 | 0.0 % |
| unknown | 58211 | 39.0 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 602 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 33 |
| R1.7 unburnable class on natural vegetation | 47 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 13 |
| R3b observed spread faster than the class can produce | 667 |

Cells with a suggested class: 77.

## Evidence cards (examples)

```
Cell (21,142)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 13
  canopy_share_ge3m_percent: 44
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 101 group GR
```

```
Cell (179,11)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 11
  worldcover_percent: {10: 88, 30: 11}
  hansen_tree_cover_2000: 22
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (224,181)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 22
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 10
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (277,27)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 7
  canopy_share_ge3m_percent: 100
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 4
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (304,48)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 11
  canopy_share_ge3m_percent: 100
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 24
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
