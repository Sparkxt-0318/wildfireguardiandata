# Fuel-map check: F_2018_CA_county (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 743696 | 76.4 % |
| contradicted | 109180 | 11.2 % |
| stale | 11747 | 1.2 % |
| unknown | 108622 | 11.2 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 29364 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 37 |
| R1.3 burnable class on open water | 739 |
| R1.5 burnable class on pavement/built | 20 |
| R1.6 burnable class on bare ground | 8 |
| R1.7 unburnable class on natural vegetation | 6021 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 58562 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 775 |
| R3b observed spread faster than the class can produce | 16055 |
| S1 wildfire perimeter after the map year | 11693 |
| S2 tree-cover loss after the map year (Hansen) | 54 |

Cells with a suggested class: 39458.

## Evidence cards (examples)

```
Cell (0,1)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 33, 30: 66}
  hansen_tree_cover_2000: 7
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (274,330)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 18
  hansen_loss_year: 2014
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (585,44)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 7
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (931,290)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 16
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 32
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1494,630)  verdict: CONTRADICTED  map class 186 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 82 (cultivated crops)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 22, 40: 77}
  hansen_tree_cover_2000: 41
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
