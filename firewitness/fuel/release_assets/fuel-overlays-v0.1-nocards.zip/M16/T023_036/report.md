# Fuel-map check: T023_036 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 2511013 | 62.8 % |
| contradicted | 1204924 | 30.1 % |
| stale | 243613 | 6.1 % |
| unknown | 40450 | 1.0 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 1162653 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 23 |
| R1.3 burnable class on open water | 328 |
| R1.5 burnable class on pavement/built | 88 |
| R1.6 burnable class on bare ground | 44903 |
| R1.7 unburnable class on natural vegetation | 99743 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 611 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 138 |
| S1 wildfire perimeter after the map year | 243612 |
| S2 tree-cover loss after the map year (Hansen) | 1 |

Cells with a suggested class: 144100.

## Evidence cards (examples)

```
Cell (0,133)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 142 group SH
```

```
Cell (351,451)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  rule R1.6: burnable class on bare ground
  tree evidence score -4 from 4 independent layers
  nlcd2021: 31 (barren)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 99 group None
```

```
Cell (703,75)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 22, 60: 77}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1207,220)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 88, 60: 11}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1999,1997)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {60: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
