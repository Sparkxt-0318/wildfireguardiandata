# Fuel-map check: F_2017_NM_corral (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 90707 | 32.1 % |
| contradicted | 12407 | 4.4 % |
| stale | 0 | 0.0 % |
| unknown | 179685 | 63.5 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 348 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 50 |
| R1.7 unburnable class on natural vegetation | 10632 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 685 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1371 |
| R3b observed spread faster than the class can produce | 694 |

Cells with a suggested class: 1873.

## Evidence cards (examples)

```
Cell (0,91)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score 1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 11
  canopy_max_m: 11
  canopy_share_ge3m_percent: 77
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (80,112)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 3
  canopy_share_ge3m_percent: 22
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (280,20)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 19
  canopy_max_m: 5
  canopy_share_ge3m_percent: 33
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (367,74)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 2 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 13
  canopy_max_m: 4
  canopy_share_ge3m_percent: 33
  worldcover_percent: {10: 77, 30: 22}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (546,426)  verdict: CONTRADICTED  map class 122 (GS)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 57
  canopy_max_m: 15
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 95
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
