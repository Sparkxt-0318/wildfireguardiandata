# Fuel-map check: F_2018_FL_flamingo (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 170640 | 75.9 % |
| contradicted | 18797 | 8.4 % |
| stale | 103 | 0.0 % |
| unknown | 35338 | 15.7 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 13719 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 3346 |
| R1.3 burnable class on open water | 23 |
| R1.5 burnable class on pavement/built | 3 |
| R1.6 burnable class on bare ground | 39 |
| R1.7 unburnable class on natural vegetation | 3 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 42 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 79 |
| R3b observed spread faster than the class can produce | 2220 |
| S1 wildfire perimeter after the map year | 1 |
| S2 tree-cover loss after the map year (Hansen) | 102 |

Cells with a suggested class: 207.

## Evidence cards (examples)

```
Cell (0,2)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 11, 30: 66, 50: 22}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (52,209)  verdict: CONTRADICTED  map class 186 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 82 (cultivated crops)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {40: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (171,309)  verdict: CONTRADICTED  map class 105 (GR)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 54
  canopy_max_m: 16
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 63
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (301,101)  verdict: CONTRADICTED  map class 148 (SH)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 90 (woody wetlands)
  tcc2021_percent: 92
  canopy_max_m: 17
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 83
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (457,483)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 55, 90: 44}
  hansen_tree_cover_2000: 27
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
