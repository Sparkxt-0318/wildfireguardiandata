# Fuel-map check: F_2017_AZ_boundary (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 177215 | 60.3 % |
| contradicted | 15370 | 5.2 % |
| stale | 0 | 0.0 % |
| unknown | 101079 | 34.4 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 4380 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 463 |
| R1.7 unburnable class on natural vegetation | 2128 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 1760 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1146 |
| R3b observed spread faster than the class can produce | 7893 |

Cells with a suggested class: 2531.

## Evidence cards (examples)

```
Cell (0,15)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 4
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (224,488)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -3 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 15
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (298,473)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 17
  canopy_share_ge3m_percent: 44
  worldcover_percent: {10: 11, 30: 88}
  hansen_tree_cover_2000: 14
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (351,216)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 23
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (551,508)  verdict: CONTRADICTED  map class 102 (GR)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 41 (deciduous forest)
  tcc2021_percent: 55
  canopy_max_m: 21
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 52
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
