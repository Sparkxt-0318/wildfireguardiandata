# Fuel-map check: F_2018_FL_curlew (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 83416 | 58.0 % |
| contradicted | 46755 | 32.5 % |
| stale | 0 | 0.0 % |
| unknown | 13604 | 9.5 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 45493 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 53 |
| R1.7 unburnable class on natural vegetation | 108 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1056 |
| R3b observed spread faster than the class can produce | 232 |

Cells with a suggested class: 0.

## Evidence cards (examples)

```
Cell (0,68)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 90 (woody wetlands)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 37
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (95,185)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (201,331)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 7
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (289,335)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 100
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 4
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (404,352)  verdict: CONTRADICTED  map class 163 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 100
  worldcover_percent: {90: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
