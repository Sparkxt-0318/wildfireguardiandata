# Fuel-map check: F_2017_MT_july (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 144595 | 75.9 % |
| contradicted | 22930 | 12.0 % |
| stale | 0 | 0.0 % |
| unknown | 23011 | 12.1 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 10160 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 930 |
| R1.3 burnable class on open water | 8 |
| R1.6 burnable class on bare ground | 1 |
| R1.7 unburnable class on natural vegetation | 7902 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 3665 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1305 |
| R3b observed spread faster than the class can produce | 600 |

Cells with a suggested class: 11835.

## Evidence cards (examples)

```
Cell (0,8)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (128,387)  verdict: CONTRADICTED  map class 102 (GR)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 65
  canopy_max_m: 17
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 95
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (216,131)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 14
  canopy_share_ge3m_percent: 55
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 45
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (327,214)  verdict: CONTRADICTED  map class 188 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 66
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 17
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (466,244)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
