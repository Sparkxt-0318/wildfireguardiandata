# Fuel-map check: F_2017_MT_arrastra_creek (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 98912 | 71.8 % |
| contradicted | 16108 | 11.7 % |
| stale | 0 | 0.0 % |
| unknown | 22806 | 16.5 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 10349 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 71 |
| R1.6 burnable class on bare ground | 27 |
| R1.7 unburnable class on natural vegetation | 1042 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 22 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 2701 |
| R3b observed spread faster than the class can produce | 3272 |

Cells with a suggested class: 210.

## Evidence cards (examples)

```
Cell (0,71)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 18
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 11, 100: 88}
  hansen_tree_cover_2000: 65
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (55,129)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 36
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 95
  hansen_loss_year: 2009
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (101,278)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 30
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 87
  hansen_loss_year: 2008
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (165,180)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 10
  canopy_share_ge3m_percent: 55
  worldcover_percent: {100: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (341,354)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 37
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
