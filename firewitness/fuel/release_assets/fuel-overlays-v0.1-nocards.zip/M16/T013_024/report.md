# Fuel-map check: T013_024 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3424019 | 85.6 % |
| contradicted | 153647 | 3.8 % |
| stale | 114269 | 2.9 % |
| unknown | 308065 | 7.7 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 44973 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 12 |
| R1.3 burnable class on open water | 10 |
| R1.5 burnable class on pavement/built | 1340 |
| R1.6 burnable class on bare ground | 1363 |
| R1.7 unburnable class on natural vegetation | 98409 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 13564 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 21889 |
| S1 wildfire perimeter after the map year | 114262 |
| S2 tree-cover loss after the map year (Hansen) | 7 |

Cells with a suggested class: 34434.

## Evidence cards (examples)

```
Cell (0,586)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 142 group SH
```

```
Cell (446,1355)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 21 (developed open)
  tcc2021_percent: 0
  canopy_max_m: 6
  canopy_share_ge3m_percent: 33
  worldcover_percent: {20: 22, 50: 55, 60: 22}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1336,472)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score 2 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 14
  canopy_max_m: 3
  canopy_share_ge3m_percent: 66
  worldcover_percent: {10: 33, 20: 66}
  hansen_tree_cover_2000: 12
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1729,218)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 77, 30: 22}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group SH
```

```
Cell (1999,1886)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 66, 60: 33}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
