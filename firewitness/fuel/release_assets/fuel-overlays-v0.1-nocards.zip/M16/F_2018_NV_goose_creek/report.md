# Fuel-map check: F_2018_NV_goose_creek (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 1370245 | 79.1 % |
| contradicted | 232419 | 13.4 % |
| stale | 117876 | 6.8 % |
| unknown | 11348 | 0.7 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 1588 |
| R1.3 burnable class on open water | 4 |
| R1.5 burnable class on pavement/built | 1 |
| R1.6 burnable class on bare ground | 48 |
| R1.7 unburnable class on natural vegetation | 2439 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 249492 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 446 |
| R3b observed spread faster than the class can produce | 27242 |
| S1 wildfire perimeter after the map year | 117876 |

Cells with a suggested class: 83492.

## Evidence cards (examples)

```
Cell (0,185)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (532,813)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -3 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 7
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (1010,381)  verdict: CONTRADICTED  map class 141 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 102 group GR
```

```
Cell (1228,549)  verdict: CONTRADICTED  map class 141 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (1687,837)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 77, 60: 22}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 141 group SH
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
