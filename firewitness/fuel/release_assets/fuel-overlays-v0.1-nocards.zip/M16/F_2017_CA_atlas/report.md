# Fuel-map check: F_2017_CA_atlas (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 529151 | 74.3 % |
| contradicted | 79339 | 11.1 % |
| stale | 0 | 0.0 % |
| unknown | 103662 | 14.6 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 16523 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 155 |
| R1.3 burnable class on open water | 539 |
| R1.5 burnable class on pavement/built | 356 |
| R1.7 unburnable class on natural vegetation | 31533 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 15204 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1828 |
| R3b observed spread faster than the class can produce | 15327 |

Cells with a suggested class: 18918.

## Evidence cards (examples)

```
Cell (0,11)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 43 (mixed forest)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 22, 30: 77}
  hansen_tree_cover_2000: 81
  hansen_loss_year: 2014
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (200,360)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -4 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 1
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 6
  hansen_loss_year: None
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class None group GR
```

```
Cell (415,306)  verdict: CONTRADICTED  map class 93 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 9
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {10: 22, 30: 77}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (712,223)  verdict: CONTRADICTED  map class 182 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 21 (developed open)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 11
  worldcover_percent: {10: 11, 30: 88}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1098,595)  verdict: CONTRADICTED  map class 121 (GS)
  rule R1.5: burnable class on pavement/built
  tree evidence score -4 from 4 independent layers
  nlcd2021: 24 (developed high)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {50: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 91 group None
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
