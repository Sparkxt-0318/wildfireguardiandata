# Fuel-map check: T009_036 (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 3454661 | 86.4 % |
| contradicted | 101318 | 2.5 % |
| stale | 387738 | 9.7 % |
| unknown | 56283 | 1.4 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 27573 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 179 |
| R1.3 burnable class on open water | 4 |
| R1.5 burnable class on pavement/built | 2 |
| R1.6 burnable class on bare ground | 35 |
| R1.7 unburnable class on natural vegetation | 67324 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 32116 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 6853 |
| S1 wildfire perimeter after the map year | 387254 |
| S2 tree-cover loss after the map year (Hansen) | 484 |

Cells with a suggested class: 22491.

## Evidence cards (examples)

```
Cell (0,337)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (510,1247)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  rule R3a: burned (perimeter + LANDFIRE disturbance) although labelled unburnable
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 66, 60: 33}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (947,201)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {20: 44, 30: 55}
  hansen_tree_cover_2000: 74
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1354,540)  verdict: CONTRADICTED  map class 99 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 77, 60: 22}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1999,1797)  verdict: CONTRADICTED  map class 91 (NB)
  rule R1.7: unburnable class on natural vegetation
  tree evidence score -4 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
