# Fuel-map check: F_2018_UT_pole_creek (M16)

Code fuel-0.1 / rules hash `65aa806449f3`; config hash `3f8614b6cb4e`.
Source map untouched (input hashes before and after are identical; see overlay.json).

| verdict | cells | share |
|---|---|---|
| consistent | 1193788 | 68.3 % |
| contradicted | 142634 | 8.2 % |
| stale | 1796 | 0.1 % |
| unknown | 408625 | 23.4 % |

| rule | cells |
|---|---|
| R1.1 timber class with no canopy in the independent layers | 60337 |
| R1.2 grass/shrub class under dense tall forest in all four independent layers | 17080 |
| R1.3 burnable class on open water | 18 |
| R1.5 burnable class on pavement/built | 737 |
| R1.6 burnable class on bare ground | 5 |
| R1.7 unburnable class on natural vegetation | 10590 |
| R1.9 grass/shrub lifeform contradicted by NLCD and WorldCover | 17397 |
| R3a burned (perimeter + LANDFIRE disturbance) although labelled unburnable | 1893 |
| R3b observed spread faster than the class can produce | 42039 |
| S1 wildfire perimeter after the map year | 660 |
| S2 tree-cover loss after the map year (Hansen) | 1136 |

Cells with a suggested class: 15972.

## Evidence cards (examples)

```
Cell (0,0)  verdict: CONTRADICTED  map class 161 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -4 from 4 independent layers
  nlcd2021: 95 (emergent wetlands)
  tcc2021_percent: 0
  canopy_max_m: 2
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (497,875)  verdict: CONTRADICTED  map class 145 (SH)
  rule R1.9: grass/shrub lifeform contradicted by NLCD and WorldCover
  tree evidence score -2 from 4 independent layers
  nlcd2021: 71 (grassland)
  tcc2021_percent: 0
  canopy_max_m: 10
  canopy_share_ge3m_percent: 88
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
  suggestion: class 101 group GR
```

```
Cell (837,365)  verdict: CONTRADICTED  map class 147 (SH)
  rule R1.2: grass/shrub class under dense tall forest in all four independent layers
  tree evidence score 4 from 4 independent layers
  nlcd2021: 42 (evergreen forest)
  tcc2021_percent: 51
  canopy_max_m: 24
  canopy_share_ge3m_percent: 100
  worldcover_percent: {10: 100}
  hansen_tree_cover_2000: 67
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1038,898)  verdict: CONTRADICTED  map class 165 (TU)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -2 from 4 independent layers
  nlcd2021: 52 (shrub/scrub)
  tcc2021_percent: 0
  canopy_max_m: 5
  canopy_share_ge3m_percent: 22
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

```
Cell (1350,1233)  verdict: CONTRADICTED  map class 183 (TL)
  rule R1.1: timber class with no canopy in the independent layers
  tree evidence score -1 from 4 independent layers
  nlcd2021: 90 (woody wetlands)
  tcc2021_percent: 9
  canopy_max_m: 0
  canopy_share_ge3m_percent: 0
  worldcover_percent: {30: 100}
  hansen_tree_cover_2000: 1
  hansen_loss_year: 2001
  wildfire_perimeter_year_after_map: None
  map_year: 2016
```

A verdict is a statement about agreement between the map and independent public layers, not a field measurement.
